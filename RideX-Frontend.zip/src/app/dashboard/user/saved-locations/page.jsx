"use client";
export default function SavedLocations() {
  return (
    <div >
      <h2 className="text-2xl font-bold mb-4">Saved Locations</h2>
      <p>Manage your saved locations here.</p>
    </div>
  );
}