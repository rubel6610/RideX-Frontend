"use client";
export default function PaymentOptions() {
  return (
    <div >
      <h2 className="text-2xl font-bold mb-4">Payment Options</h2>
      <p>Manage your payment options here.</p>
    </div>
  );
}