"use client";
export default function UpcomingRides() {
  return (
    <div >
      <h2 className="text-2xl font-bold mb-4">Upcoming Rides</h2>
      <p>View your upcoming rides here.</p>
    </div>
  );
}